Hapus code di bagian js buat programnya berjalan lancar :)
